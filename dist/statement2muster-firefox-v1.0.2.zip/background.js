// Safe background script supporting both Firefox sidebarAction and Chrome sidePanel
if (typeof browser !== 'undefined' && browser.action && browser.sidebarAction) {
  browser.action.onClicked.addListener(() => {
    browser.sidebarAction.open().catch((err) => console.error("Error opening sidebar:", err));
  });
} else if (typeof chrome !== 'undefined' && chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.sidePanel
    .setPanelBehavior({ openPanelOnActionClick: true })
    .catch((error) => console.error("Error setting sidePanel behavior:", error));
}
